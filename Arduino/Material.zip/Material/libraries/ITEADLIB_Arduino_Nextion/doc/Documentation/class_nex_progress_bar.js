var class_nex_progress_bar =
[
    [ "NexProgressBar", "class_nex_progress_bar.html#a61f76f0c855c7839630dbc930e3401d8", null ],
    [ "Get_background_color_bco", "class_nex_progress_bar.html#a2efc0d6694d8739fb9caa31c53190271", null ],
    [ "Get_font_color_pco", "class_nex_progress_bar.html#aa148721b86c5f56c6321780da3ef974f", null ],
    [ "getValue", "class_nex_progress_bar.html#a3e5eb13b2aa014c8f6a9e16439917bf2", null ],
    [ "Set_background_color_bco", "class_nex_progress_bar.html#ab0b4230a6559989080e2a7b66b42ffc1", null ],
    [ "Set_font_color_pco", "class_nex_progress_bar.html#a0ee8478a28a3c31d4b7179317299f711", null ],
    [ "setValue", "class_nex_progress_bar.html#aaa7937d364cb63151bd1e1bc4729334d", null ]
];