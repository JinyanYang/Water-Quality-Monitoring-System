var class_nex_variable =
[
    [ "NexVariable", "class_nex_variable.html#a7d36d19e14c991872fb1547f3ced09b2", null ],
    [ "getText", "class_nex_variable.html#ab4d12f14dcff3f6930a2bdf5e1f3d259", null ],
    [ "getValue", "class_nex_variable.html#aff06d16d022876c749d3e30f020b1557", null ],
    [ "setText", "class_nex_variable.html#aab59ac44eb0804664a03c09932be70eb", null ],
    [ "setValue", "class_nex_variable.html#a9da9d4a74f09e1787e4e4562da1e4833", null ]
];