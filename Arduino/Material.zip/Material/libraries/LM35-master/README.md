LM35 Temperature Sensor Library
===============================

## How to install
* Unpack the archive and rename the result to 'LM35'.
* Put it in the 'libraries' folder in your Arduino sketches area.
* Restart the Arduino IDE to make sure it sees the new files.
